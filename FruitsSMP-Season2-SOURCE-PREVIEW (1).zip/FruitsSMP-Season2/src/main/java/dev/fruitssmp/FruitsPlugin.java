package dev.fruitssmp;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** Preview implementation. Not a drop-in replacement for Season 1. */
public final class FruitsPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private static final List<String> TYPES = List.of("shadow","abyssal","chaos","nova","lynx","ivory");
    private final Map<UUID,String> fruits = new HashMap<>();
    private final Map<String,Long> cooldowns = new HashMap<>();
    private final Map<UUID,Integer> hits = new HashMap<>();
    private final Map<UUID,Long> lastHit = new HashMap<>();
    private final Map<UUID,Set<UUID>> trusted = new HashMap<>();
    private final Set<UUID> shadowInvisible = new HashSet<>();
    private final Set<UUID> novaFall = new HashSet<>();
    private final Set<UUID> chaosCrit = new HashSet<>();
    private final Map<UUID,Long> lynxRush = new HashMap<>();
    private final Map<UUID,Long> shieldDisabled = new HashMap<>();
    private final Map<UUID,Long> bleeding = new HashMap<>();
    private NamespacedKey key;
    private boolean starfall;
    private long starfallEnds;

    @Override public void onEnable() {
        key = new NamespacedKey(this,"fruit");
        saveDefaultConfig();
        for (String type : TYPES) for (String uuid : getConfig().getStringList("owners."+type)) {
            try { fruits.put(UUID.fromString(uuid),type); } catch (IllegalArgumentException ignored) {}
        }
        for (String uuid : getConfig().getStringList("trusted-owners")) {
            try { UUID owner=UUID.fromString(uuid); Set<UUID> set=new HashSet<>();
                for (String t:getConfig().getStringList("trusted."+uuid)) set.add(UUID.fromString(t)); trusted.put(owner,set);
            } catch (IllegalArgumentException ignored) {}
        }
        getServer().getPluginManager().registerEvents(this,this);
        for (String cmd : List.of("fruit","trust","untrust","start")) Objects.requireNonNull(getCommand(cmd)).setExecutor(this);
        getServer().getScheduler().runTaskTimer(this,this::tick,20,20);
        getLogger().info("Season 2 fruit preview enabled. This does NOT include Season 1 Bites/repair/reroller systems.");
    }
    @Override public void onDisable() {
        for(String type:TYPES) { List<String> owners=new ArrayList<>(); fruits.forEach((id,f)->{if(f.equals(type))owners.add(id.toString());}); getConfig().set("owners."+type,owners); }
        List<String> ids=new ArrayList<>(); trusted.forEach((id,set)->{ids.add(id.toString());getConfig().set("trusted."+id,set.stream().map(UUID::toString).toList());});
        getConfig().set("trusted-owners",ids); saveConfig();
    }
    private String type(Player p){return fruits.getOrDefault(p.getUniqueId(),"");}
    private boolean ready(Player p,String slot,int seconds){
        String k=p.getUniqueId()+":"+slot; long now=System.currentTimeMillis();long end=cooldowns.getOrDefault(k,0L);
        if(now<end){p.sendMessage(ChatColor.RED+"Cooldown: "+((end-now+999)/1000)+"s");return false;}
        cooldowns.put(k,now+seconds*1000L);return true;
    }
    private void fx(Location l,Particle particle,int count){l.getWorld().spawnParticle(particle,l,count,1.3,1.1,1.3,0.04);}
    private void effect(Player p,PotionEffectType e,int seconds,int amplifier){p.addPotionEffect(new PotionEffect(e,seconds*20,amplifier,true,true));}
    private boolean enemy(Player p,Player other){return !p.equals(other)&&!trusted.getOrDefault(p.getUniqueId(),Set.of()).contains(other.getUniqueId());}
    private List<Player> nearbyEnemies(Player p,double radius){List<Player> out=new ArrayList<>();for(Entity e:p.getNearbyEntities(radius,radius,radius))if(e instanceof Player q&&enemy(p,q))out.add(q);return out;}
    private void damage(Player attacker,LivingEntity target,double hearts){target.damage(hearts*2,attacker);}
    private void cast(Player p,int slot){String t=type(p);if(t.isEmpty()){p.sendMessage("You have no fruit. Ask an admin to assign one.");return;}
        switch(t){
            case "shadow" -> {if(slot==1){if(!ready(p,"a1",30))return;shadowInvisible.add(p.getUniqueId());effect(p,PotionEffectType.INVISIBILITY,5,0);p.setInvisible(true);p.getWorld().playSound(p,Sound.ENTITY_ENDERMAN_TELEPORT,1,.6f);new BukkitRunnable(){public void run(){shadowInvisible.remove(p.getUniqueId());p.setInvisible(false);}}.runTaskLater(this,100);}
                else {if(!ready(p,"a2",55))return; for(int i=0;i<3;i++){Location loc=p.getLocation().clone().add(Math.cos(i*2.094)*2,0,Math.sin(i*2.094)*2);Wolf w=p.getWorld().spawn(loc,Wolf.class);w.setCustomName(ChatColor.DARK_PURPLE+"Shadow Clone");w.setCustomNameVisible(true);w.setMaxHealth(10);w.setHealth(10);w.setCollarColor(DyeColor.BLACK);w.setOwner(p);w.setSilent(true);Player target=nearestEnemy(p,15);if(target!=null)w.setTarget(target);new BukkitRunnable(){public void run(){if(w.isValid())w.remove();}}.runTaskLater(this,200);}}}
            }
            case "abyssal" -> {if(slot==1){if(!ready(p,"a1",50))return;Location centre=p.getLocation().clone().add(p.getLocation().getDirection().multiply(5));for(int i=0;i<10;i++){int tick=i;new BukkitRunnable(){public void run(){for(Player q:nearbyEnemies(p,20))if(q.getWorld().equals(centre.getWorld())&&Math.abs(q.getLocation().getX()-centre.getX())<=2.5&&Math.abs(q.getLocation().getZ()-centre.getZ())<=2.5){damage(p,q,1);fx(q.getLocation(),Particle.END_ROD,15);}fx(centre.clone().add(0,8,0),Particle.END_ROD,30);}}.runTaskLater(this,tick*20L);}}
                else {if(!ready(p,"a2",45))return;for(Player q:nearbyEnemies(p,12)){damage(p,q,2.5);Location locked=q.getLocation().clone();for(int i=0;i<60;i+=2){new BukkitRunnable(){public void run(){if(q.isOnline()&&q.getWorld().equals(locked.getWorld())){q.teleport(locked);fx(locked,Particle.PORTAL,8);}}}.runTaskLater(this,i);}}}}
            }
            case "chaos" -> {if(slot==1){if(!ready(p,"a1",50))return;effect(p,PotionEffectType.SPEED,8,1);for(int i=0;i<16;i++){int n=i;new BukkitRunnable(){public void run(){Location l=p.getLocation();for(int j=0;j<4;j++){double a=n*.6+j*Math.PI/2;fx(l.clone().add(Math.cos(a)*2,1,Math.sin(a)*2),Particle.FLAME,5);}if(n%4==0)for(Player q:nearbyEnemies(p,2.8))damage(p,q,1);}}.runTaskLater(this,i*10L);}}
                else {if(!ready(p,"a2",60))return;fx(p.getLocation(),Particle.FLAME,130);for(Player q:nearbyEnemies(p,10)){damage(p,q,3);q.setVelocity(q.getVelocity().add(new Vector(0,.95,0)));effect(q,PotionEffectType.WEAKNESS,5,0);}}}
            }
            case "nova" -> {if(slot==1){if(!ready(p,"a1",55))return;fx(p.getEyeLocation().add(0,2,0),Particle.END_ROD,50);new BukkitRunnable(){public void run(){fx(p.getLocation(),Particle.END_ROD,160);for(Player q:nearbyEnemies(p,9)){damage(p,q,3.5);q.setVelocity(q.getLocation().toVector().subtract(p.getLocation().toVector()).normalize().multiply(1.1).add(new Vector(0,.2,0)));effect(q,PotionEffectType.GLOWING,6,0);}}}.runTaskLater(this,40);}
                else {if(!ready(p,"a2",45))return;Player q=nearestEnemy(p,18);if(q==null){p.sendMessage("No opponent within 18 blocks.");return;}for(int i=0;i<5;i++){new BukkitRunnable(){public void run(){if(!q.isOnline())return;fx(q.getLocation().add(0,6,0),Particle.END_ROD,35);damage(p,q,.8);}}.runTaskLater(this,i*20L);}}}
            }
            case "lynx" -> {if(slot==1){if(!ready(p,"a1",90))return;effect(p,PotionEffectType.HASTE,30,3);effect(p,PotionEffectType.SPEED,15,1);lynxRush.put(p.getUniqueId(),System.currentTimeMillis()+30000);fx(p.getLocation(),Particle.HAPPY_VILLAGER,100);}
                else {if(!ready(p,"a2",75))return;effect(p,PotionEffectType.NIGHT_VISION,30,0);p.giveExpLevels(25);for(ItemStack stack:p.getInventory().getContents())if(stack!=null&&stack.getType()==Material.APPLE)stack.setType(Material.GOLDEN_APPLE);p.sendMessage(ChatColor.GOLD+"Treasure Pulse: ores within 20 blocks glow briefly as particles; true X-ray requires a client resource pack/mod.");for(int x=-20;x<=20;x+=2)for(int y=-12;y<=12;y+=2)for(int z=-20;z<=20;z+=2){Block b=p.getLocation().clone().add(x,y,z).getBlock();if(b.getType().name().endsWith("_ORE")||b.getType()==Material.ANCIENT_DEBRIS)fx(b.getLocation().add(.5,.5,.5),Particle.HAPPY_VILLAGER,1);}}}
            }
            case "ivory" -> {if(slot==1){if(!ready(p,"a1",45))return;int count=0;for(Player q:nearbyEnemies(p,12)){if(count++>=4)break;damage(p,q,2.5);p.setHealth(Math.min(p.getMaxHealth(),p.getHealth()+2));Location lock=q.getLocation().clone();for(int i=0;i<80;i+=2){new BukkitRunnable(){public void run(){if(q.isOnline()&&q.getWorld().equals(lock.getWorld())){q.teleport(lock);fx(lock,Particle.HAPPY_VILLAGER,5);}}}.runTaskLater(this,i);}}}
                else {if(!ready(p,"a2",65))return;Location centre=p.getLocation().clone();for(int i=0;i<10;i++){new BukkitRunnable(){public void run(){fx(centre,Particle.HAPPY_VILLAGER,80);for(Entity e:centre.getWorld().getNearbyEntities(centre,10,5,10))if(e instanceof Player q){if(q.equals(p)||!enemy(p,q))effect(q,PotionEffectType.REGENERATION,2,2);else effect(q,PotionEffectType.WEAKNESS,2,1);}}}.runTaskLater(this,i*20L);}}}
        }
    }
    private Player nearestEnemy(Player p,int range){Player best=null;double d=range*range;for(Player q:nearbyEnemies(p,range)){double v=p.getLocation().distanceSquared(q.getLocation());if(v<d){d=v;best=q;}}return best;}
    private void tick(){long now=System.currentTimeMillis();if(starfall&&now>=starfallEnds){starfall=false;Bukkit.broadcastMessage(ChatColor.BLUE+"Starfall ended.");}
        for(Player p:Bukkit.getOnlinePlayers()){String f=type(p);if(f.equals("abyssal")&&(p.getLocation().getBlock().getLightLevel()<=7||p.getWorld().getBiome(p.getLocation()).name().contains("DEEP_DARK"))){effect(p,PotionEffectType.SPEED,3,0);effect(p,PotionEffectType.RESISTANCE,3,0);fx(p.getLocation(),Particle.PORTAL,3);}
            if(f.equals("nova")&&starfall)effect(p,PotionEffectType.RESISTANCE,3,0);
            if(f.equals("lynx"))effect(p,PotionEffectType.HERO_OF_THE_VILLAGE,3,9);
            if(f.equals("ivory")){String biome=p.getLocation().getBlock().getBiome().name();if(biome.contains("PLAINS")||biome.contains("FOREST"))effect(p,PotionEffectType.SPEED,3,0);}
        }
    }
    @EventHandler public void onInteract(PlayerInteractEvent e){if(!e.getAction().isRightClick())return;ItemStack item=e.getItem();if(item==null)return;String tagged=item.getItemMeta()!=null?item.getItemMeta().getPersistentDataContainer().get(key,PersistentDataType.STRING):null;if(tagged!=null&&TYPES.contains(tagged)){e.setCancelled(true);fruits.put(e.getPlayer().getUniqueId(),tagged);e.getPlayer().sendMessage(ChatColor.GREEN+"Equipped "+tagged+" fruit!");return;}if(e.getPlayer().isSneaking()&&e.getHand()==EquipmentSlot.HAND)cast(e.getPlayer(),2);else if(e.getHand()==EquipmentSlot.HAND)cast(e.getPlayer(),1);}
    @EventHandler public void onSneak(PlayerToggleSneakEvent e){Player p=e.getPlayer();if(e.isSneaking()&&type(p).equals("shadow")&&ready(p,"dash",5)){Vector v=p.getLocation().getDirection().normalize().multiply(.95);v.setY(.7);p.setVelocity(v);fx(p.getLocation(),Particle.PORTAL,20);}}
    @EventHandler public void onDamage(EntityDamageEvent e){if(e.getEntity() instanceof Player p&&type(p).equals("nova")&&(e.getCause()==EntityDamageEvent.DamageCause.FALL||e.getCause()==EntityDamageEvent.DamageCause.CONTACT))e.setCancelled(true);}
    @EventHandler public void onHit(EntityDamageByEntityEvent e){if(!(e.getDamager() instanceof Player p)||!(e.getEntity() instanceof Player q)||!enemy(p,q))return;String f=type(p);long now=System.currentTimeMillis();if(now-lastHit.getOrDefault(p.getUniqueId(),0L)>5000)hits.put(p.getUniqueId(),0);lastHit.put(p.getUniqueId(),now);int count=hits.merge(p.getUniqueId(),1,Integer::sum);
        if(f.equals("chaos")){if(readySilent(p,"autocrit",90)){chaosCrit.add(p.getUniqueId());new BukkitRunnable(){public void run(){chaosCrit.remove(p.getUniqueId());}}.runTaskLater(this,200);}if(chaosCrit.contains(p.getUniqueId()))e.setDamage(e.getDamage()*1.5);if(count>=12){hits.put(p.getUniqueId(),0);int r=ThreadLocalRandom.current().nextInt(3);if(r==0)e.setDamage(e.getDamage()+3);else if(r==1){bleeding.put(q.getUniqueId(),now+4000);for(int i=0;i<4;i++)new BukkitRunnable(){public void run(){if(q.isOnline()&&System.currentTimeMillis()<bleeding.getOrDefault(q.getUniqueId(),0L))q.damage(1,p);}}.runTaskLater(this,(i+1)*20L);}else{shieldDisabled.put(q.getUniqueId(),now+7000);q.setCooldown(Material.SHIELD,140);}}}
        if(f.equals("abyssal")&&count>=15){hits.put(p.getUniqueId(),0);e.setDamage(e.getDamage()+2);effect(q,PotionEffectType.DARKNESS,6,0);fx(q.getLocation(),Particle.PORTAL,35);}
        if(f.equals("shadow")&&shadowInvisible.contains(p.getUniqueId()))e.setCancelled(true);
    }
    private boolean readySilent(Player p,String slot,int seconds){String k=p.getUniqueId()+":"+slot;long now=System.currentTimeMillis();if(now<cooldowns.getOrDefault(k,0L))return false;cooldowns.put(k,now+seconds*1000L);return true;}
    @EventHandler public void onBlock(BlockBreakEvent e){Player p=e.getPlayer();if(!type(p).equals("lynx")||System.currentTimeMillis()>lynxRush.getOrDefault(p.getUniqueId(),0L))return;Material m=e.getBlock().getType();if(!m.name().endsWith("_ORE")&&m!=Material.ANCIENT_DEBRIS)return;if(ThreadLocalRandom.current().nextDouble()<.20){for(ItemStack drop:e.getBlock().getDrops(p.getInventory().getItemInMainHand())){ItemStack copy=drop.clone();if(copy.getType()==Material.RAW_IRON)copy.setType(Material.IRON_INGOT);if(copy.getType()==Material.RAW_GOLD)copy.setType(Material.GOLD_INGOT);if(copy.getType()==Material.RAW_COPPER)copy.setType(Material.COPPER_INGOT);e.getBlock().getWorld().dropItemNaturally(e.getBlock().getLocation(),copy);}}}
    @EventHandler public void onExp(PlayerExpChangeEvent e){if(type(e.getPlayer()).equals("lynx"))e.setAmount((int)Math.round(e.getAmount()*1.7));}
    @EventHandler public void onPotion(EntityPotionEffectEvent e){if(!(e.getEntity() instanceof Player p)||!type(p).equals("shadow"))return;PotionEffect n=e.getNewEffect();if(n!=null&&n.getType().equals(PotionEffectType.INVISIBILITY)&&!shadowInvisible.contains(p.getUniqueId())&&e.getCause()!=EntityPotionEffectEvent.Cause.PLUGIN){new BukkitRunnable(){public void run(){if(p.isOnline())p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY,n.getDuration()*2,n.getAmplifier()));}}.runTaskLater(this,1);}}
    @Override public boolean onCommand(CommandSender sender,Command cmd,String label,String[] args){String name=cmd.getName();if(name.equals("start")){if(!sender.hasPermission("fruits.admin"))return true;if(args.length>0&&args[0].equalsIgnoreCase("starfall")){starfall=true;starfallEnds=System.currentTimeMillis()+20*60*1000L;Bukkit.broadcastMessage(ChatColor.BLUE+"Starfall has begun for 20 minutes!");}return true;}
        if(!(sender instanceof Player p)){sender.sendMessage("Use this in game.");return true;}
        if(name.equals("trust")||name.equals("untrust")){if(args.length<1)return false;Player q=Bukkit.getPlayerExact(args[0]);if(q==null){p.sendMessage("Player must be online.");return true;}if(name.equals("trust"))trusted.computeIfAbsent(p.getUniqueId(),id->new HashSet<>()).add(q.getUniqueId());else trusted.computeIfAbsent(p.getUniqueId(),id->new HashSet<>()).remove(q.getUniqueId());p.sendMessage("Updated trusted players.");return true;}
        if(args.length==0||args[0].equalsIgnoreCase("info")){p.sendMessage(ChatColor.GOLD+"Season 2 fruits: "+String.join(", ",TYPES));p.sendMessage("Your fruit: "+type(p)+". Right-click item: ability 1; sneak-right-click: ability 2; sneak: Shadow dash.");return true;}
        if(args[0].equalsIgnoreCase("ability1")){cast(p,1);return true;}if(args[0].equalsIgnoreCase("ability2")){cast(p,2);return true;}
        if(args[0].equalsIgnoreCase("give")&&p.hasPermission("fruits.admin")&&args.length>=3){Player q=Bukkit.getPlayerExact(args[1]);String f=args[2].toLowerCase(Locale.ROOT);if(q==null||!TYPES.contains(f)){p.sendMessage("Usage: /fruit give <online player> <fruit>");return true;}ItemStack item=new ItemStack(Material.NETHER_STAR);ItemMeta meta=item.getItemMeta();meta.setDisplayName(ChatColor.LIGHT_PURPLE+f.toUpperCase(Locale.ROOT)+" FRUIT");meta.getPersistentDataContainer().set(key,PersistentDataType.STRING,f);item.setItemMeta(meta);q.getInventory().addItem(item);p.sendMessage("Given "+f+" fruit to "+q.getName());return true;}
        if(args[0].equalsIgnoreCase("set")&&p.hasPermission("fruits.admin")&&args.length>=3){Player q=Bukkit.getPlayerExact(args[1]);String f=args[2].toLowerCase(Locale.ROOT);if(q!=null&&TYPES.contains(f)){fruits.put(q.getUniqueId(),f);p.sendMessage("Set "+q.getName()+" to "+f);}return true;}
        return false;
    }
}
