# Fruits SMP Season 2 — Source preview

**NOT a finished or tested plugin JAR.** This is a Java 21 / Paper 1.21.11 Gradle project implementing a starting point for the six fruits. Build with `gradle build` on a machine with internet access. The output is in `build/libs/`.

## Important limitations
- This is **not** a binary patch of MagicFruits 2.3.84. It does not contain the Season 1 Bites, repair, reroll, event, weapon, resource-pack or player migration systems.
- Fruit items use placeholder nether stars, not the 3D art. A separately modeled resource pack is needed.
- Shadow clones are temporary black-collared wolves, not exact player replicas.
- Abyssal tentacles and Ivory tree are particle-only approximations, not custom 3D models.
- Lynx treasure pulse uses ore particles rather than real client X-ray. Automatic smelting is incomplete.
- Lynx no-lapis enchanting and guaranteed apples-to-golden-apples from all sources are not implemented.
- Nova Starfall can be started manually with `/start starfall`; the every-six-nights scheduling is not implemented.
- Chaos automatic critical hits are implemented as a 10-second window every 90 seconds (the user did not specify duration).
- Ivory biome movement uses Speed I, which is not an exact +25% movement multiplier.
- Shadow true invisibility is a vanilla invisibility approximation; armor may still show to other players.
- Potion extension, damage balance and plugin API compatibility require testing.
- This source has not been compiled in this environment because the Paper API dependency is unavailable offline.

## Commands
- `/fruit info`
- `/fruit ability1`, `/fruit ability2`
- `/fruit give <player> <shadow|abyssal|chaos|nova|lynx|ivory>` (OP)
- `/fruit set <player> <fruit>` (OP)
- `/trust <player>`, `/untrust <player>`
- `/start starfall` (OP)

**Do not install alongside the original MagicFruits without testing for collisions.**
